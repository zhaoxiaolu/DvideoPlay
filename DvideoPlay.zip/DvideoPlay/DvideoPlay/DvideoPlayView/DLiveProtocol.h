//
//  DLiveProtocol.h
//  DvideoPlay
//
//  Created by DUCHENGWEN on 2016/11/28.
//  Copyright © 2016年 DCW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DLiveProtocol : UIView

-(void)addFITFastForwardView:(NSString*)ImgView durationString:(NSString*)durationString currentPlaybackTimeString:(NSString*)currentPlaybackTimeString;

@end
