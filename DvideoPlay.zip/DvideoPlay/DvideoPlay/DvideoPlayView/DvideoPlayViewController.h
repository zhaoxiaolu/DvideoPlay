//
//  DvideoPlayViewController.h
//  DvideoPlay
//
//  Created by DUCHENGWEN on 2016/11/28.
//  Copyright © 2016年 DCW. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DvideoPlayViewController : UIViewController

@end
