//
//  KSYMediaPlayer.h
//  KSYMediaPlayer
//
//  Created by 施雪梅 on 16/8/31.
//  Copyright © 2016年 施雪梅. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "KSYMediaPlayer/KSYMoviePlayerController.h"

//! Project version number for KSYMediaPlayer.
FOUNDATION_EXPORT double KSYMediaPlayerVersionNumber;

//! Project version string for KSYMediaPlayer.
FOUNDATION_EXPORT const unsigned char KSYMediaPlayerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KSYMediaPlayer/PublicHeader.h>


